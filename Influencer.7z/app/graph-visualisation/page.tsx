export default function GraphVisualisation() {
    return (
        <div className="flex flex-col h-screen">
            <div className="flex-1 overflow-y-auto">
                <div className="space-y-4 p-4">
                    <div className="flex items-center gap-4">
                        <div className="font-bold">Graph Visualisation</div>
                    </div>
                    <div className="border-t border-b py-2">
                        <div className="flex items-center gap-4">
                            <div className="flex-1">
                                <div className="font-bold">Graph</div>
                            </div>
                            <div className="flex-1">
                                <div className="font-bold">Actions</div>
                            </div>
                        </div>
                    </div>
                    <div className="border-b py-2">
                        <div className="flex items-center gap-4">
                            <div className="flex-1">Graph 1</div>
                            <div className="flex-1">
                                <button className="text-blue-500 hover:underline">Edit</button>
                                <button className="text-red-500 hover:underline">Delete</button>
                            </div>
                        </div>
                    </div>
                    <div className="border-b py-2">
                        <div className="flex items-center gap-4">
                            <div className="flex-1">Graph 2</div>
                            <div className="flex-1">
                                <button className="text-blue-500 hover:underline">Edit</button>
                                <button className="text-red-500 hover:underline">Delete</button>
                            </div>
                        </div>
                    </div>
                    <div className="border-b py-2">
                        <div className="flex items-center gap-4">
                            <div className="flex-1">Graph 3</div>
                            <div className="flex-1">
                                <button className="text-blue-500 hover:underline">Edit</button>
                                <button className="text-red-500 hover:underline">Delete</button>
                            </div>
                        </div>
                    </div>
                    <div className="border-b py-2">
                        <div className="flex items-center gap-4">
                            <div className="flex-1">Graph 4</div>
                            <div className="flex-1">
                                <button className="text-blue-500 hover:underline">Edit</button>
                                <button className="text-red-500 hover:underline">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}