export default function Home() {


    const tweets = []


    return (
      <div className="flex flex-col h-screen">
        <div className="flex-1 overflow-y-auto">
            {tweets.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                    <div className="text-gray-400">No tweets found</div>
                </div>
            ) : (<div>Tweets is found</div>)
            }
        </div>
      </div>
    )
}