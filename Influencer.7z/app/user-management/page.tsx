"use client"

import {useState, useMemo, useEffect} from "react"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table"
import { Label } from "@/components/ui/label"
import { UserManagementData } from "@/data/database"
import {GetUserManagementData} from "@/REST API/User";

export default function UserManagement() {
    const [users, setUsers] = useState<UserManagementData[]>([])
    const [selectedUser, setSelectedUser] = useState<UserManagementData | null>(null)
    const [sortBy, setSortBy] = useState("name")
    const [sortOrder, setSortOrder] = useState("asc")
    const [filterText, setFilterText] = useState("")
    useEffect(() => {
        const fetchUsers = async () => {
            const users = await GetUserManagementData()
            const formattedData = users.map((user) => ({
                ...user,
                joinDate: new Date(user.joinDate).toLocaleDateString(),
            }))
            setUsers(formattedData)
        }
        fetchUsers()
    }, [])
    const handleSort = (key) => {
        if (sortBy === key) {
            setSortOrder(sortOrder === "asc" ? "desc" : "asc")
        } else {
            setSortBy(key)
            setSortOrder("asc")
        }
    }

    const handleFilter = (e) => {
        setFilterText(e.target.value)
    }
    const handleEdit = (user) => {
        setSelectedUser(user)
    }
    const handleDelete = (userId) => {
        setUsers(users.filter((user) => user.id !== userId))
    }
    const handleBatchUpload = () => {}
    const sortedUsers = useMemo(() => {
        return users.sort((a, b) => {
            if (a[sortBy] < b[sortBy]) return sortOrder === "asc" ? -1 : 1
            if (a[sortBy] > b[sortBy]) return sortOrder === "asc" ? 1 : -1
            return 0
        })
    }, [users, sortBy, sortOrder])
    const filteredUsers = useMemo(() => {
        return sortedUsers.filter((user) => user.name.toLowerCase().includes(filterText.toLowerCase()))
    }, [sortedUsers, filterText])
    return (
        <div className="flex flex-col h-screen">
            <main className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
                <div className="bg-background rounded-lg shadow-md p-4">
                    <div className="flex items-center justify-between mb-4">
                        <h2 className="text-xl font-bold">User List</h2>
                        <div className="flex items-center gap-2">
                            <Input placeholder="Filter by name" value={filterText} onChange={handleFilter} />
                            <Button onClick={() => handleBatchUpload()}>Batch Upload</Button>
                            <Button onClick={() => handleBatchUpload()}>Add new user</Button>
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button variant="outline">
                                        Sort by {sortBy} ({sortOrder})
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent>
                                    <DropdownMenuItem onClick={() => handleSort("name")}>Name</DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => handleSort("followers")}>Followers</DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => handleSort("joinDate")}>Join Date</DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => handleSort("tweets")}>Tweets</DropdownMenuItem>
                                </DropdownMenuContent>
                            </DropdownMenu>
                        </div>
                    </div>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Name</TableHead>
                                <TableHead>Followers</TableHead>
                                <TableHead>Join Date</TableHead>
                                <TableHead>Tweets</TableHead>
                                <TableHead>Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {filteredUsers.map((user) => (
                                <TableRow key={user.id}>
                                    <TableCell>
                                        <Button variant="link" onClick={() => setSelectedUser(user)}>
                                            {user.name}
                                        </Button>
                                    </TableCell>
                                    <TableCell>{user.followers}</TableCell>
                                    <TableCell>{user.joinDate}</TableCell>
                                    <TableCell>{user.tweets}</TableCell>
                                    <TableCell>
                                        <Button variant="outline" size="sm" onClick={() => handleEdit(user)}>
                                            Edit
                                        </Button>
                                        <Button variant="outline" size="sm" onClick={() => handleDelete(user.id)}>
                                            Delete
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
                {selectedUser && (
                    <div className="bg-background rounded-lg shadow-md p-4">
                        <div className="flex items-center justify-between mb-4">
                            <h2 className="text-xl font-bold">User Details</h2>
                            <Button variant="outline" size="sm" onClick={() => setSelectedUser(null)}>
                                Close
                            </Button>
                        </div>
                        <div className="grid gap-4">
                            <div>
                                <Label>Name</Label>
                                <Input
                                    value={selectedUser.name}
                                    onChange={(e) => setSelectedUser({ ...selectedUser, name: e.target.value })}
                                />
                            </div>
                            <div>
                                <Label>Followers</Label>
                                <Input
                                    type="number"
                                    value={selectedUser.followers}
                                    onChange={(e) =>
                                        setSelectedUser({
                                            ...selectedUser,
                                            followers: parseInt(e.target.value),
                                        })
                                    }
                                />
                            </div>
                            <div>
                                <Label>Join Date</Label>
                                <Input
                                    type="date"
                                    value={selectedUser.joinDate}
                                    onChange={(e) => setSelectedUser({
                                        ...selectedUser,
                                        joinDate: e.target.value }
                                    )}
                                />
                            </div>
                            <div>
                                <Label>Tweets</Label>
                                <div className="grid gap-2">
                                    {selectedUser.tweetsData !== null && selectedUser.tweetsData.map((tweet) => (
                                        <div key={tweet.id} className="bg-muted p-2 rounded">
                                            {tweet.content}
                                        </div>
                                    ))}
                                </div>
                            </div>
                            <div className="flex justify-end gap-2">
                                <Button variant="outline" onClick={() => setSelectedUser(null)}>
                                    Cancel
                                </Button>
                                <Button>Save</Button>
                            </div>
                        </div>
                    </div>
                )}
            </main>
        </div>
    )
}