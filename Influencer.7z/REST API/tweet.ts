"use server"


import {db} from "@/lib/db";
import {Tweet} from "@prisma/client";

// CRUD operations for tweets -------------------------------
export async function createTweet(content: string, userId: string) {
    const tweet = await db.tweet.create({
        data: {
            content,
            userId,
            author: {
                connect: {
                    id: userId,
                },
            },
        },
    });
    if (!tweet) {
        return {error: "Failed to create tweet"};
    }
    return {success: "Tweet created successfully"};
}

export async function getTweet(id: number) {
    const tweet = await db.tweet.findUnique({
        where: {
            id: id,
        },
    });
    if (!tweet) {
        return {error: "Tweet not found"};
    }
    return tweet;
}

export async function updateTweet(tweet: Tweet) {
    const updatedTweet = await db.tweet.update({
        where: {
            id: tweet.id,
        },
        data: tweet,
    });
    if (!updatedTweet) {
        return {error: "Failed to update tweet"};
    }
    return {success: "Tweet updated successfully"};
}

export async function deleteTweet(id: number) {
    const tweet = await db.tweet.delete({
        where: {
            id: id,
        },
    });
    if (!tweet) {
        return {error: "Failed to delete tweet"};
    }
    return {success: "Tweet deleted successfully"};
}