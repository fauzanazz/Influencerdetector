"use server"

import {User} from "@prisma/client";
import {db} from "@/lib/db";

export const getAllUsers = async () => {
    const users = await db.user.findMany();
    return users;
}

export const getAllTweets = async () => {
    const tweets = await db.tweet.findMany();
    return tweets;
}

// CRUD operations for users -------------------------------
export async function createUser(name: string) {
    const user = await db.user.create({
        data: {
            name,
        },
    });
    if (!user) {
        return {error: "Failed to create user"};
    }
    return {success: "User created successfully"};
}

export async function getUser(id: string) {
    const user = await db.user.findUnique({
        where: {
            id: id,
        },
    });
    if (!user) {
        return {error: "User not found"};
    }
    return user;
}

export async function updateUser(Users: User) {
    const user = await db.user.update({
        where: {
            id: Users.id,
        },
        data: Users,
    });

    if (!user) {
        return {error: "Failed to update user"};
    };

    return {success: "User updated successfully"};
}


export async function deleteUser(id: string) {
    const user = await db.user.delete({
        where: {
            id: id,
        },
    });
    if (!user) {
        return {error: "Failed to delete user"};
    }
    return {success: "User deleted successfully"};
}

// ------------------ User Management Page ------------------

export const GetUserManagementData = async () => {
    const users = await getAllUsers();
    const tweets = await getAllTweets();

    const data = users.map((user) => {
        const userTweets = tweets.filter((tweet) => tweet.userId === user.id);
        const tweetsData = userTweets.map((tweet) => {
            return {
                id: tweet.id,
                content: tweet.content,
            };
        });
        return {
            id: user.id,
            name: user.name,
            followers: user.followers,
            joinDate: user.joinDate,
            tweets: userTweets.length,
            tweetsData: tweetsData,
        };
    });

    return data;
}

