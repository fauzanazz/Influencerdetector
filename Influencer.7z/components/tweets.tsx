import {Avatar, AvatarFallback, AvatarImage} from "@/components/ui/avatar";
import {Button} from "@/components/ui/button";
import {JSX, SVGProps} from "react";

export const Tweets = () => {
    return (
        <div className="flex items-start gap-4">
            <Avatar className="w-12 h-12">
                <AvatarImage src="/placeholder-user.jpg" alt="@shadcn"/>
                <AvatarFallback>AC</AvatarFallback>
            </Avatar>
            <div className="flex-1">
                <div className="flex items-center gap-2">
                    <div className="font-bold">Acme Inc</div>
                    <div className="text-gray-500">@acme</div>
                    <div className="text-gray-500">· 3h</div>
                </div>
                <p className="mt-2">
                    Excited to announce our latest product launch! Check it out and let us know what you think.
                </p>
                <div className="flex items-center gap-4 mt-2">
                    <Button variant="ghost" size="icon" className="rounded-full">
                        <MessageCircleIcon className="w-5 h-5 text-gray-600"/>
                    </Button>
                    <Button variant="ghost" size="icon" className="rounded-full">
                        <RepeatIcon className="w-5 h-5 text-gray-600"/>
                    </Button>
                    <Button variant="ghost" size="icon" className="rounded-full">
                        <HeartIcon className="w-5 h-5 text-gray-600"/>
                    </Button>
                    <Button variant="ghost" size="icon" className="rounded-full">
                        <ShareIcon className="w-5 h-5 text-gray-600"/>
                    </Button>
                </div>
            </div>
        </div>
    )
}

function HeartIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
    return (
        <svg
            {...props}
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
        >
            <path
                d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>
        </svg>
    )
}

function RepeatIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
    return (
        <svg
            {...props}
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
        >
            <path d="m17 2 4 4-4 4"/>
            <path d="M3 11v-1a4 4 0 0 1 4-4h14"/>
            <path d="m7 22-4-4 4-4"/>
            <path d="M21 13v1a4 4 0 0 1-4 4H3"/>
        </svg>
    )
}





function ShareIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
    return (
        <svg
            {...props}
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
        >
            <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/>
            <polyline points="16 6 12 2 8 6"/>
            <line x1="12" x2="12" y1="2" y2="15"/>
        </svg>
    )
}



function MessageCircleIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
    return (
        <svg
            {...props}
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
        >
            <path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>
        </svg>
    )
}


